package com.clutchsync.clutchsync.config;

import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@EntityScan("com.clutchsync.clutchsync.domain")
@EnableJpaRepositories("com.clutchsync.clutchsync.repos")
@EnableTransactionManagement
public class DomainConfig {
}
