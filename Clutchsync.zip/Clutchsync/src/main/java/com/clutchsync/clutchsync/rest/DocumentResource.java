package com.clutchsync.clutchsync.rest;

import com.clutchsync.clutchsync.model.DocumentDTO;
import com.clutchsync.clutchsync.service.DocumentService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/documents", produces = MediaType.APPLICATION_JSON_VALUE)
public class DocumentResource {

    private final DocumentService documentService;

    public DocumentResource(final DocumentService documentService) {
        this.documentService = documentService;
    }

    @GetMapping
    public ResponseEntity<List<DocumentDTO>> getAllDocuments() {
        return ResponseEntity.ok(documentService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DocumentDTO> getDocument(@PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(documentService.get(id));
    }

    @PostMapping
    public ResponseEntity<Long> createDocument(@RequestBody @Valid final DocumentDTO documentDTO) {
        final Long createdId = documentService.create(documentDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Long> updateDocument(@PathVariable(name = "id") final Long id,
            @RequestBody @Valid final DocumentDTO documentDTO) {
        documentService.update(id, documentDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDocument(@PathVariable(name = "id") final Long id) {
        documentService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
