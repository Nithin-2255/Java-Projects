package com.clutchsync.clutchsync.repos;

import com.clutchsync.clutchsync.domain.LoginHistory;
import org.springframework.data.jpa.repository.JpaRepository;


public interface LoginHistoryRepository extends JpaRepository<LoginHistory, Long> {

    LoginHistory findFirstByUserId(Long id);

}
