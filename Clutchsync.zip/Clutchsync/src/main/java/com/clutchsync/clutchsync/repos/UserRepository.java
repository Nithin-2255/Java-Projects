package com.clutchsync.clutchsync.repos;

import com.clutchsync.clutchsync.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User, Long> {

    boolean existsByEmailIgnoreCase(String email);

}
