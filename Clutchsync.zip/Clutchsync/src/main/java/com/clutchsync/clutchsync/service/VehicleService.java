package com.clutchsync.clutchsync.service;

import com.clutchsync.clutchsync.domain.User;
import com.clutchsync.clutchsync.domain.Vehicle;
import com.clutchsync.clutchsync.events.BeforeDeleteUser;
import com.clutchsync.clutchsync.events.BeforeDeleteVehicle;
import com.clutchsync.clutchsync.model.VehicleDTO;
import com.clutchsync.clutchsync.repos.UserRepository;
import com.clutchsync.clutchsync.repos.VehicleRepository;
import com.clutchsync.clutchsync.util.CustomCollectors;
import com.clutchsync.clutchsync.util.NotFoundException;
import com.clutchsync.clutchsync.util.ReferencedException;
import java.util.List;
import java.util.Map;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class VehicleService {

    private final VehicleRepository vehicleRepository;
    private final UserRepository userRepository;
    private final ApplicationEventPublisher publisher;

    public VehicleService(final VehicleRepository vehicleRepository,
            final UserRepository userRepository, final ApplicationEventPublisher publisher) {
        this.vehicleRepository = vehicleRepository;
        this.userRepository = userRepository;
        this.publisher = publisher;
    }

    public List<VehicleDTO> findAll() {
        final List<Vehicle> vehicles = vehicleRepository.findAll(Sort.by("id"));
        return vehicles.stream()
                .map(vehicle -> mapToDTO(vehicle, new VehicleDTO()))
                .toList();
    }

    public VehicleDTO get(final Long id) {
        return vehicleRepository.findById(id)
                .map(vehicle -> mapToDTO(vehicle, new VehicleDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final VehicleDTO vehicleDTO) {
        final Vehicle vehicle = new Vehicle();
        mapToEntity(vehicleDTO, vehicle);
        return vehicleRepository.save(vehicle).getId();
    }

    public void update(final Long id, final VehicleDTO vehicleDTO) {
        final Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(vehicleDTO, vehicle);
        vehicleRepository.save(vehicle);
    }

    public void delete(final Long id) {
        final Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        publisher.publishEvent(new BeforeDeleteVehicle(id));
        vehicleRepository.delete(vehicle);
    }

    private VehicleDTO mapToDTO(final Vehicle vehicle, final VehicleDTO vehicleDTO) {
        vehicleDTO.setId(vehicle.getId());
        vehicleDTO.setVehicleNumber(vehicle.getVehicleNumber());
        vehicleDTO.setVehicleType(vehicle.getVehicleType());
        vehicleDTO.setBrand(vehicle.getBrand());
        vehicleDTO.setModel(vehicle.getModel());
        vehicleDTO.setYear(vehicle.getYear());
        vehicleDTO.setUser(vehicle.getUser() == null ? null : vehicle.getUser().getId());
        return vehicleDTO;
    }

    private Vehicle mapToEntity(final VehicleDTO vehicleDTO, final Vehicle vehicle) {
        vehicle.setVehicleNumber(vehicleDTO.getVehicleNumber());
        vehicle.setVehicleType(vehicleDTO.getVehicleType());
        vehicle.setBrand(vehicleDTO.getBrand());
        vehicle.setModel(vehicleDTO.getModel());
        vehicle.setYear(vehicleDTO.getYear());
        final User user = vehicleDTO.getUser() == null ? null : userRepository.findById(vehicleDTO.getUser())
                .orElseThrow(() -> new NotFoundException("user not found"));
        vehicle.setUser(user);
        return vehicle;
    }

    public boolean vehicleNumberExists(final String vehicleNumber) {
        return vehicleRepository.existsByVehicleNumberIgnoreCase(vehicleNumber);
    }

    public Map<Long, String> getVehicleValues() {
        return vehicleRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Vehicle::getId, Vehicle::getVehicleNumber));
    }

    @EventListener(BeforeDeleteUser.class)
    public void on(final BeforeDeleteUser event) {
        final ReferencedException referencedException = new ReferencedException();
        final Vehicle userVehicle = vehicleRepository.findFirstByUserId(event.getId());
        if (userVehicle != null) {
            referencedException.setKey("user.vehicle.user.referenced");
            referencedException.addParam(userVehicle.getId());
            throw referencedException;
        }
    }

}
