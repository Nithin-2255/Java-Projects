package com.clutchsync.clutchsync.repos;

import com.clutchsync.clutchsync.domain.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;


public interface VehicleRepository extends JpaRepository<Vehicle, Long> {

    Vehicle findFirstByUserId(Long id);

    boolean existsByVehicleNumberIgnoreCase(String vehicleNumber);

}
