package com.clutchsync.clutchsync.service;

import com.clutchsync.clutchsync.domain.LoginHistory;
import com.clutchsync.clutchsync.events.BeforeDeleteUser;
import com.clutchsync.clutchsync.repos.LoginHistoryRepository;
import com.clutchsync.clutchsync.util.ReferencedException;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;


@Service
public class LoginHistoryService {

    private final LoginHistoryRepository loginHistoryRepository;

    public LoginHistoryService(final LoginHistoryRepository loginHistoryRepository) {
        this.loginHistoryRepository = loginHistoryRepository;
    }

    @EventListener(BeforeDeleteUser.class)
    public void on(final BeforeDeleteUser event) {
        final ReferencedException referencedException = new ReferencedException();
        final LoginHistory userLoginHistory = loginHistoryRepository.findFirstByUserId(event.getId());
        if (userLoginHistory != null) {
            referencedException.setKey("user.loginHistory.user.referenced");
            referencedException.addParam(userLoginHistory.getId());
            throw referencedException;
        }
    }

}
