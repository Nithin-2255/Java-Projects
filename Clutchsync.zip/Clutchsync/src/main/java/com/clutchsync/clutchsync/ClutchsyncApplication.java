package com.clutchsync.clutchsync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ClutchsyncApplication {

    public static void main(final String[] args) {
        SpringApplication.run(ClutchsyncApplication.class, args);
    }

}
