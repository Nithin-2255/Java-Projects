package com.clutchsync.clutchsync.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


public class VehicleDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    @VehicleVehicleNumberUnique
    private String vehicleNumber;

    @NotNull
    @Size(max = 20)
    private String vehicleType;

    @Size(max = 30)
    private String brand;

    @Size(max = 255)
    private String model;

    private Integer year;

    @NotNull
    private Long user;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(final String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(final String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(final String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(final String model) {
        this.model = model;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(final Integer year) {
        this.year = year;
    }

    public Long getUser() {
        return user;
    }

    public void setUser(final Long user) {
        this.user = user;
    }

}
