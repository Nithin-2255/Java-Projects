package com.clutchsync.clutchsync.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


public class DocumentDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    private String documentType;

    @NotNull
    @Size(max = 255)
    private String fileName;

    @NotNull
    @Size(max = 255)
    private String filePath;

    @Size(max = 255)
    private String uploadDate;

    @NotNull
    private Long user;

    @NotNull
    private Long vehicle;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(final String documentType) {
        this.documentType = documentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(final String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(final String filePath) {
        this.filePath = filePath;
    }

    public String getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(final String uploadDate) {
        this.uploadDate = uploadDate;
    }

    public Long getUser() {
        return user;
    }

    public void setUser(final Long user) {
        this.user = user;
    }

    public Long getVehicle() {
        return vehicle;
    }

    public void setVehicle(final Long vehicle) {
        this.vehicle = vehicle;
    }

}
