package com.clutchsync.clutchsync.events;


public class BeforeDeleteVehicle {

    private Long id;

    public BeforeDeleteVehicle(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

}
