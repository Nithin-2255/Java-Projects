package com.clutchsync.clutchsync.events;


public class BeforeDeleteUser {

    private Long id;

    public BeforeDeleteUser(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

}
