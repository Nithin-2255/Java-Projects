package com.clutchsync.clutchsync.service;

import com.clutchsync.clutchsync.domain.Document;
import com.clutchsync.clutchsync.domain.User;
import com.clutchsync.clutchsync.domain.Vehicle;
import com.clutchsync.clutchsync.events.BeforeDeleteUser;
import com.clutchsync.clutchsync.events.BeforeDeleteVehicle;
import com.clutchsync.clutchsync.model.DocumentDTO;
import com.clutchsync.clutchsync.repos.DocumentRepository;
import com.clutchsync.clutchsync.repos.UserRepository;
import com.clutchsync.clutchsync.repos.VehicleRepository;
import com.clutchsync.clutchsync.util.NotFoundException;
import com.clutchsync.clutchsync.util.ReferencedException;
import java.util.List;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final UserRepository userRepository;
    private final VehicleRepository vehicleRepository;

    public DocumentService(final DocumentRepository documentRepository,
            final UserRepository userRepository, final VehicleRepository vehicleRepository) {
        this.documentRepository = documentRepository;
        this.userRepository = userRepository;
        this.vehicleRepository = vehicleRepository;
    }

    public List<DocumentDTO> findAll() {
        final List<Document> documents = documentRepository.findAll(Sort.by("id"));
        return documents.stream()
                .map(document -> mapToDTO(document, new DocumentDTO()))
                .toList();
    }

    public DocumentDTO get(final Long id) {
        return documentRepository.findById(id)
                .map(document -> mapToDTO(document, new DocumentDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final DocumentDTO documentDTO) {
        final Document document = new Document();
        mapToEntity(documentDTO, document);
        return documentRepository.save(document).getId();
    }

    public void update(final Long id, final DocumentDTO documentDTO) {
        final Document document = documentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(documentDTO, document);
        documentRepository.save(document);
    }

    public void delete(final Long id) {
        final Document document = documentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        documentRepository.delete(document);
    }

    private DocumentDTO mapToDTO(final Document document, final DocumentDTO documentDTO) {
        documentDTO.setId(document.getId());
        documentDTO.setDocumentType(document.getDocumentType());
        documentDTO.setFileName(document.getFileName());
        documentDTO.setFilePath(document.getFilePath());
        documentDTO.setUploadDate(document.getUploadDate());
        documentDTO.setUser(document.getUser() == null ? null : document.getUser().getId());
        documentDTO.setVehicle(document.getVehicle() == null ? null : document.getVehicle().getId());
        return documentDTO;
    }

    private Document mapToEntity(final DocumentDTO documentDTO, final Document document) {
        document.setDocumentType(documentDTO.getDocumentType());
        document.setFileName(documentDTO.getFileName());
        document.setFilePath(documentDTO.getFilePath());
        document.setUploadDate(documentDTO.getUploadDate());
        final User user = documentDTO.getUser() == null ? null : userRepository.findById(documentDTO.getUser())
                .orElseThrow(() -> new NotFoundException("user not found"));
        document.setUser(user);
        final Vehicle vehicle = documentDTO.getVehicle() == null ? null : vehicleRepository.findById(documentDTO.getVehicle())
                .orElseThrow(() -> new NotFoundException("vehicle not found"));
        document.setVehicle(vehicle);
        return document;
    }

    @EventListener(BeforeDeleteUser.class)
    public void on(final BeforeDeleteUser event) {
        final ReferencedException referencedException = new ReferencedException();
        final Document userDocument = documentRepository.findFirstByUserId(event.getId());
        if (userDocument != null) {
            referencedException.setKey("user.document.user.referenced");
            referencedException.addParam(userDocument.getId());
            throw referencedException;
        }
    }

    @EventListener(BeforeDeleteVehicle.class)
    public void on(final BeforeDeleteVehicle event) {
        final ReferencedException referencedException = new ReferencedException();
        final Document vehicleDocument = documentRepository.findFirstByVehicleId(event.getId());
        if (vehicleDocument != null) {
            referencedException.setKey("vehicle.document.vehicle.referenced");
            referencedException.addParam(vehicleDocument.getId());
            throw referencedException;
        }
    }

}
