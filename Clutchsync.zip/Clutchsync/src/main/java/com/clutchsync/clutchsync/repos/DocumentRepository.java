package com.clutchsync.clutchsync.repos;

import com.clutchsync.clutchsync.domain.Document;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DocumentRepository extends JpaRepository<Document, Long> {

    Document findFirstByUserId(Long id);

    Document findFirstByVehicleId(Long id);

}
